/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState } from 'react';
import Header from './components/Header';
import MapCard from './components/MapCard';
import Filters from './components/Filters';
import RestaurantCard from './components/RestaurantCard';
import ItinerarySidebar from './components/ItinerarySidebar';
import TaxiModal from './components/TaxiModal';
import Toast from './components/Toast';
import { restaurants, departuresData } from './data';
import { DepartureCode, CategoryCode, Restaurant } from './types';

export default function App() {
  // Caching states to prevent page resets on refreshing or HMR
  const [selectedDeparture, setSelectedDeparture] = useState<DepartureCode>(() => {
    try {
      const saved = localStorage.getItem('daejeon_tour_pref_dep');
      if (saved && (saved === 'ansan' || saved === 'seoul' || saved === 'incheon' || saved === 'suwon' || saved === 'gwangju' || saved === 'busan')) {
        return saved as DepartureCode;
      }
    } catch (e) {
      // Ignored
    }
    return 'ansan';
  });

  const [activeCategory, setActiveCategory] = useState<CategoryCode>('all');
  const [filterNearSubway, setFilterNearSubway] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const [itinerary, setItinerary] = useState<Restaurant[]>(() => {
    try {
      const saved = localStorage.getItem('daejeon_tour_itinerary');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      // Ignored
    }
    return [];
  });

  const [showTaxiModal, setShowTaxiModal] = useState<boolean>(false);
  const [toast, setToast] = useState<{ show: boolean; message: string }>({ show: false, message: '' });

  const showToast = (message: string) => {
    setToast({ show: true, message });
  };

  const handleSelectDeparture = (code: DepartureCode) => {
    setSelectedDeparture(code);
    try {
      localStorage.setItem('daejeon_tour_pref_dep', code);
    } catch (e) {
      // Ignored
    }
  };

  const handleToggleRestaurant = (res: Restaurant) => {
    const exists = itinerary.some((item) => item.id === res.id);
    let updated: Restaurant[] = [];

    if (exists) {
      updated = itinerary.filter((item) => item.id !== res.id);
      showToast(`'${res.name}' 일정이 일정표에서 제외되었습니다.`);
    } else {
      updated = [...itinerary, res];
      showToast(`'${res.name}' 일정이 성공적으로 추가되었습니다!`);
    }

    setItinerary(updated);
    try {
      localStorage.setItem('daejeon_tour_itinerary', JSON.stringify(updated));
    } catch (e) {
      // Ignored
    }
  };

  const handleRemoveItem = (id: number) => {
    const itemToRemove = itinerary.find((item) => item.id === id);
    const updated = itinerary.filter((item) => item.id !== id);
    setItinerary(updated);
    try {
      localStorage.setItem('daejeon_tour_itinerary', JSON.stringify(updated));
    } catch (e) {
      // Ignored
    }
    if (itemToRemove) {
      showToast(`'${itemToRemove.name}' 일정이 삭제되었습니다.`);
    }
  };

  const handleClearAll = () => {
    setItinerary([]);
    try {
      localStorage.setItem('daejeon_tour_itinerary', JSON.stringify([]));
    } catch (e) {
      // Ignored
    }
    showToast("일정표가 깨끗하게 초기화되었습니다.");
  };

  // Filter computation
  const filteredRestaurants = restaurants.filter((item) => {
    if (activeCategory !== 'all' && item.category !== activeCategory) {
      return false;
    }
    if (filterNearSubway && !item.nearSubway) {
      return false;
    }
    if (searchQuery.trim() !== '') {
      const q = searchQuery.toLowerCase();
      const nameMatch = item.name.toLowerCase().includes(q);
      const menuMatch = item.menu.toLowerCase().includes(q);
      const tagMatch = item.tags.some((tag) => tag.toLowerCase().includes(q));
      if (!nameMatch && !menuMatch && !tagMatch) {
        return false;
      }
    }
    return true;
  });

  const departureName = departuresData[selectedDeparture]?.name || "안산시 📍";

  return (
    <div className="relative min-h-screen bg-slate-950 text-slate-100 flex flex-col overflow-hidden antialiased">
      {/* Mesh Gradient Background Blobs for Frosted Glass effect */}
      <div className="absolute -top-24 -left-24 w-96 h-96 bg-indigo-600/20 rounded-full blur-[100px] pointer-events-none"></div>
      <div className="absolute top-1/3 -right-24 w-80 h-80 bg-teal-500/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-1/4 left-1/3 w-64 h-64 bg-rose-500/10 rounded-full blur-[80px] pointer-events-none"></div>

      <Header onOpenTaxiModal={() => setShowTaxiModal(true)} />

      {/* Main Grid Container */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Side: Map and Filters and Restaurant list (7 columns) */}
        <section className="lg:col-span-7 space-y-6">
          <MapCard 
            selectedDeparture={selectedDeparture} 
            onSelectDeparture={handleSelectDeparture} 
          />

          <Filters 
            searchQuery={searchQuery}
            onSearchQueryChange={setSearchQuery}
            activeCategory={activeCategory}
            onSelectCategory={setActiveCategory}
            filterNearSubway={filterNearSubway}
            onToggleSubwayOnly={() => setFilterNearSubway(!filterNearSubway)}
          />

          {/* Restaurants Grid Display */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5" id="restaurantGrid">
            {filteredRestaurants.length === 0 ? (
              <div className="col-span-full py-16 text-center bg-slate-950/40 rounded-3xl border border-slate-800/80">
                <span className="text-4xl block mb-4">🔍</span>
                <p className="text-slate-400 font-bold">조건에 일치하는 맛집이 없습니다.</p>
                <p className="text-[11px] text-slate-500 mt-1">다른 검색 키워드를 입력하거나 카테고리 필터를 조정해보세요.</p>
              </div>
            ) : (
              filteredRestaurants.map((item) => (
                <RestaurantCard 
                  key={item.id}
                  restaurant={item}
                  isAdded={itinerary.some((it) => it.id === item.id)}
                  onToggle={() => handleToggleRestaurant(item)}
                />
              ))
            )}
          </div>
        </section>

        {/* Right Side: Travel Itinerary Sequence (5 columns) */}
        <section className="lg:col-span-5">
          <ItinerarySidebar 
            itinerary={itinerary}
            departureName={departureName}
            onRemoveItem={handleRemoveItem}
            onClearAll={handleClearAll}
            onShowToast={showToast}
          />
        </section>

      </main>

      {/* Footer copyright */}
      <footer className="bg-slate-950 border-t border-slate-900 py-8 mt-12">
        <div className="max-w-7xl mx-auto px-4 text-center text-xs text-slate-500 space-y-2">
          <p>© 2026 대전 맛투어 디지털 가이드 - 트렌디한 감각의 고품격 여행 플래너</p>
          <p className="text-[10px] text-slate-600">지도 데이터를 바탕으로 가장 효율적인 실시간 이동수단이 자동 계산됩니다.</p>
        </div>
      </footer>

      {/* Overlays / Modals */}
      <TaxiModal isOpen={showTaxiModal} onClose={() => setShowTaxiModal(false)} />
      
      <Toast 
        show={toast.show} 
        message={toast.message} 
        onClose={() => setToast({ show: false, message: '' })} 
      />
    </div>
  );
}
