/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type DepartureCode = 'ansan' | 'seoul' | 'incheon' | 'suwon' | 'gwangju' | 'busan';

export interface TransportOption {
  name: string;
  time: string;
  efficiency: string;
  pct: number;
  isBest: boolean;
}

export interface DepartureData {
  name: string;
  bestRecommend: string;
  transports: TransportOption[];
}

export type CategoryCode = 'all' | 'korean' | 'chinese' | 'japanese' | 'western' | 'dessert';

export interface Restaurant {
  id: number;
  name: string;
  category: CategoryCode;
  subway: string;
  nearSubway: boolean;
  menu: string;
  description: string;
  tips: string;
  icon: string;
  tags: string[];
}
