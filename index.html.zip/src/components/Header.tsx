/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Compass, Car } from 'lucide-react';

interface HeaderProps {
  onOpenTaxiModal: () => void;
}

export default function Header({ onOpenTaxiModal }: HeaderProps) {
  return (
    <header className="bg-white/5 backdrop-blur-xl border-b border-white/10 sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-indigo-500 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/30 shrink-0">
            <Compass className="w-5 h-5 text-white animate-spin-slow" />
          </div>
          <div>
            <h1 className="font-extrabold text-sm sm:text-base tracking-tight text-white flex items-center gap-2">
              <span>대전 웰니스 맛투어 로드맵</span>
              <span className="bg-teal-500/20 text-teal-300 text-[10px] font-bold px-2 py-0.5 rounded-full border border-teal-500/30">v2.0</span>
            </h1>
            <p className="text-[10px] text-slate-400 font-medium uppercase tracking-wider hidden sm:block">Smart Wellness Gourmet Guide</p>
          </div>
        </div>
        
        <div className="flex items-center space-x-3">
          <div className="hidden md:flex items-center bg-slate-900/50 rounded-full px-3 py-1.5 border border-white/5">
            <div className="w-2 h-2 bg-teal-400 rounded-full animate-pulse mr-2"></div>
            <span className="text-[10px] font-bold tracking-wider text-slate-300">LIVE TRAFFIC: OPTIMAL</span>
          </div>

          <button 
            id="btn-taxi-modal"
            onClick={onOpenTaxiModal} 
            className="flex items-center space-x-2 bg-white/10 hover:bg-white/20 active:scale-95 text-white border border-white/10 font-bold py-2 px-3 sm:px-4 rounded-xl text-xs transition duration-200"
          >
            <Car className="w-4 h-4 text-teal-400" />
            <span>빵택시 & 시티버스 팁</span>
          </button>
        </div>
      </div>
    </header>
  );
}
