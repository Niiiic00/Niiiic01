/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { X, Info, Bus, MapPin, Subtitles } from 'lucide-react';

interface TaxiModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function TaxiModal({ isOpen, onClose }: TaxiModalProps) {
  if (!isOpen) return null;

  return (
    <div id="taxi-modal-backdrop" className="fixed inset-0 bg-slate-950/80 z-50 flex items-center justify-center p-4 backdrop-blur-md transition-opacity duration-300">
      <div 
        id="taxi-modal-content"
        className="bg-slate-900/95 backdrop-blur-lg border border-white/10 rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl transform scale-100 transition-all duration-300 relative"
      >
        <div className="bg-white/5 p-6 text-white relative border-b border-white/10">
          <button 
            onClick={onClose} 
            className="absolute top-4 right-4 text-slate-400 hover:text-white text-xl transition active:scale-95 p-1 rounded-lg hover:bg-white/10 cursor-pointer"
            title="닫기"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="flex items-center space-x-3">
            <span className="text-3xl">🚖</span>
            <div>
              <h3 className="font-bold text-lg text-white">대전 빵택시 & 시티버스 100% 활용법</h3>
              <p className="text-xs text-teal-400 mt-0.5">땀 한 방울 흘리지 않고 즐기는 대전 빵지순례</p>
            </div>
          </div>
        </div>

        {/* Modal Content Body */}
        <div className="p-6 space-y-5 max-h-[60vh] overflow-y-auto text-sm leading-relaxed text-slate-300">
          <div className="bg-slate-950/40 border border-white/5 p-4 rounded-2xl flex gap-3">
            <Info className="w-5 h-5 text-teal-400 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold text-white text-xs">
                대전 '빵택시' 운행 공식 정보
              </p>
              <p className="text-xs text-slate-300 mt-1.5 leading-normal">
                기존의 개인 단위의 즉흥 탑승 대신, 현재는 <strong className="text-teal-400">고급형 제휴 모빌리티 서비스</strong> 또는 관광 여행 연계 플랫폼(연트래블 등)의 패키지 투어 형태로 안전하고 쾌적하게 운행되고 있습니다. 사전에 빵택시 예약 전용 채널을 통해 차량 예약을 확인하는 것이 좋습니다.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="font-bold text-white text-xs border-b border-white/10 pb-1.5 flex items-center gap-1.5">
              <span>💡 예약이 어려울 때의 완벽한 뚜벅이 대안</span>
            </h4>
            <ul className="space-y-4 text-xs">
              <li className="flex items-start gap-2.5">
                <span className="bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-[10px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <p className="font-semibold text-slate-200 flex items-center gap-1">
                    <Bus className="w-3.5 h-3.5 text-indigo-400" />
                    <span>대전시 주관 '대찬 버스 - 빵시투어' 이용</span>
                  </p>
                  <p className="text-slate-400 mt-1">
                    대형 시티투어 순환형 버스를 통해 매우 저렴하고 에어컨이 빵빵한 전용 버스로 대흥동, 자양동, 은행동의 주요 베이커리를 동선 낭비 없이 완주할 수 있습니다.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 text-[10px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <p className="font-semibold text-slate-200 flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-indigo-400" />
                    <span>지하철 1호선 노선 밀집 이용</span>
                  </p>
                  <p className="text-slate-400 mt-1">
                    대전역을 중심으로 중앙로역 근방 도보 5~10분 내 구역(성심당, 미소본가 스마일칼국수, 정동문화사, 카라멜 등)에 유명 명소가 모여 있어 여름에도 무리 없이 투어가 가능합니다.
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Modal Action Footer */}
        <div className="p-4 bg-slate-950/60 border-t border-white/10 flex justify-end">
          <button 
            id="btn-taxi-modal-close"
            onClick={onClose} 
            className="bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-2.5 px-6 rounded-xl transition text-xs active:scale-95 cursor-pointer"
          >
            확인완료
          </button>
        </div>

      </div>
    </div>
  );
}
