/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect } from 'react';
import { CheckCircle2 } from 'lucide-react';

interface ToastProps {
  show: boolean;
  message: string;
  onClose: () => void;
}

export default function Toast({ show, message, onClose }: ToastProps) {
  useEffect(() => {
    if (show) {
      const timer = setTimeout(() => {
        onClose();
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [show, onClose]);

  if (!show) return null;

  return (
    <div 
      id="toast-notification" 
      className="fixed bottom-5 left-1/2 transform -translate-x-1/2 bg-slate-800 text-slate-100 text-xs font-semibold px-6 py-3.5 rounded-2xl shadow-2xl border border-slate-700 z-50 flex items-center space-x-2 animate-bounce-short"
      style={{ transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)' }}
    >
      <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" />
      <span>{message}</span>
    </div>
  );
}
