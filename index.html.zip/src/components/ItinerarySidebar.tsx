/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Route, Trash2, Copy, X, MapPin, Milestone } from 'lucide-react';
import { Restaurant } from '../types';

interface ItinerarySidebarProps {
  itinerary: Restaurant[];
  departureName: string;
  onRemoveItem: (id: number) => void;
  onClearAll: () => void;
  onShowToast: (msg: string) => void;
}

export default function ItinerarySidebar({
  itinerary,
  departureName,
  onRemoveItem,
  onClearAll,
  onShowToast,
}: ItinerarySidebarProps) {
  
  const handleCopy = () => {
    if (itinerary.length === 0) {
      onShowToast("복사할 일정이 없습니다. 맛집을 먼저 추가해 주세요!");
      return;
    }

    let text = `✨ [대전 웰니스 맛투어 여행 일정표] ✨\n`;
    text += `🛫 출발지: ${departureName}\n\n`;
    text += `📍 추천 동선:\n`;
    itinerary.forEach((item, index) => {
      text += `👉 [Step ${index + 1}] ${item.name} (${item.icon})\n`;
      text += `   - 시그니처: ${item.menu}\n`;
      text += `   - 위치/대중교통: ${item.subway}\n`;
      text += `   - 로컬 꿀팁: ${item.tips}\n\n`;
    });
    text += `💡 꿀팁: 맛집 이름을 네이버/카카오 지도에 검색하여 경로 탐색을 시작해 보세요!\n`;
    text += `© 2026 대전 맛투어 디지털 가이드`;

    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text)
        .then(() => {
          onShowToast("일정표가 클립보드에 성공적으로 복사되었습니다! 카톡이나 메모장에 붙여넣어 보세요.");
        })
        .catch(() => {
          onShowToast("복사에 실패했습니다. 브라우저 권한을 확인해 주세요.");
        });
    } else {
      // Fallback
      const textArea = document.createElement("textarea");
      textArea.value = text;
      document.body.appendChild(textArea);
      textArea.select();
      try {
        document.execCommand('copy');
        onShowToast("일정표가 클립보드에 성공적으로 복사되었습니다! 카톡이나 메모장에 붙여넣어 보세요.");
      } catch (err) {
        onShowToast("복사에 실패했습니다.");
      }
      document.body.removeChild(textArea);
    }
  };

  return (
    <aside id="itinerary-sidebar" className="bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 overflow-hidden lg:sticky lg:top-24 shadow-2xl">
      
      {/* Itinerary Header */}
      <div className="bg-white/5 p-5 border-b border-white/10 flex items-center justify-between">
        <div>
          <h3 className="font-bold text-base text-white flex items-center gap-2">
            <Route className="w-5 h-5 text-teal-400" />
            <span>나의 대전 여행 로드맵</span>
          </h3>
          <p className="text-xs text-slate-400 mt-1">
            {itinerary.length === 0 
              ? "맛집 카드에서 내 일정을 설계해 보세요" 
              : `현재 총 ${itinerary.length}개의 일정이 안전하게 기록되었습니다.`}
          </p>
        </div>
        {itinerary.length > 0 && (
          <button 
            onClick={onClearAll} 
            className="text-xs bg-white/10 hover:bg-white/20 text-slate-300 py-1.5 px-3 rounded-lg border border-white/5 transition active:scale-95 flex items-center gap-1 font-semibold cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>초기화</span>
          </button>
        )}
      </div>

      {/* Dynamic Step-by-Step List */}
      <div className="p-6 space-y-4 max-h-[50vh] overflow-y-auto">
        {itinerary.length === 0 ? (
          <div className="py-16 text-center text-slate-500 flex flex-col items-center justify-center">
            <Milestone className="w-12 h-12 mb-3 text-slate-600 animate-pulse" />
            <p className="text-xs font-bold text-slate-400">생성된 이동 경로 일정이 없습니다.</p>
            <p className="text-[10px] mt-1 text-slate-500">맛집 카드에서 원하는 일정을 골라 담아보세요!</p>
          </div>
        ) : (
          <div className="space-y-1">
            {/* Start Hub: Daejeon Station */}
            <div className="flex items-center gap-3 bg-slate-950/40 border border-white/5 p-3 rounded-2xl">
              <span className="bg-teal-500 text-slate-950 font-extrabold text-[11px] w-5 h-5 rounded-full flex items-center justify-center shrink-0">
                S
              </span>
              <div className="flex-grow">
                <p className="font-bold text-xs text-teal-400">출발지 도착</p>
                <p className="text-[10px] text-slate-400">대전역에 안전하게 진입합니다.</p>
              </div>
              <MapPin className="w-4 h-4 text-teal-400 shrink-0" />
            </div>

            {itinerary.map((item, index) => {
              const isLast = index === itinerary.length - 1;
              return (
                <div key={item.id} className="relative pt-3">
                  {/* Vertical line connecting steps */}
                  <div className="absolute left-[13px] top-0 bottom-0 w-[2px] bg-indigo-500/20 z-0"></div>

                  <div className="relative z-10 flex items-center gap-3 bg-slate-950/40 border border-white/5 p-3.5 rounded-2xl shadow-md hover:border-white/15 hover:bg-slate-950/60 transition">
                    <span className="bg-indigo-500 text-white font-extrabold text-[11px] w-5 h-5 rounded-full flex items-center justify-center shrink-0">
                      {index + 1}
                    </span>
                    <span className="text-xl shrink-0">{item.icon}</span>
                    <div className="flex-grow min-w-0">
                      <p className="font-bold text-xs text-slate-100 truncate">{item.name}</p>
                      <p className="text-[10px] text-slate-400 truncate">시그니처: {item.menu}</p>
                    </div>
                    <button 
                      onClick={() => onRemoveItem(item.id)}
                      className="text-slate-500 hover:text-rose-400 p-1 rounded-lg transition shrink-0 cursor-pointer"
                      title="제거"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Call to Action Footer */}
      <div className="p-6 bg-slate-950/50 border-t border-white/10 space-y-4">
        <button 
          onClick={handleCopy} 
          className="w-full flex items-center justify-center space-x-2 bg-indigo-500 hover:bg-indigo-600 active:scale-95 text-white font-bold py-3 px-4 rounded-2xl transition shadow-lg shadow-indigo-500/20 text-sm cursor-pointer"
        >
          <Copy className="w-4 h-4" />
          <span>내 카톡/메모장으로 일정 복사하기</span>
        </button>
        <p className="text-[10px] text-slate-500 text-center leading-normal">
          선택한 맛집 위치와 동선을 복사하여 대중교통 경로 탐색기나 지도 어플에 바로 붙여넣어 연동해 보세요!
        </p>
      </div>

    </aside>
  );
}
