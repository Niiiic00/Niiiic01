/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MapPinned, Sparkles } from 'lucide-react';
import { DepartureCode } from '../types';
import { departuresData } from '../data';

interface MapCardProps {
  selectedDeparture: DepartureCode;
  onSelectDeparture: (code: DepartureCode) => void;
}

export default function MapCard({ selectedDeparture, onSelectDeparture }: MapCardProps) {
  const depData = departuresData[selectedDeparture];

  return (
    <div id="map-card" className="bg-white/5 backdrop-blur-lg border border-white/10 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
      <div className="absolute -top-10 -right-10 w-40 h-40 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none"></div>
      <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>
      
      <h3 className="font-bold text-lg text-white flex items-center gap-2 mb-2">
        <MapPinned className="w-5 h-5 text-indigo-400" />
        <span>출발지별 실시간 대전행 교통 효율 맵</span>
      </h3>
      <p className="text-xs text-slate-400 mb-6">지도에서 출발지를 클릭하여 대전역까지 가장 빠르고 시원한 교통수단을 비교해보세요.</p>

      {/* Interactive SVG Map & Route Data Combined Layout */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
          
        {/* SVG Interactive Transit Map (5 Cols) */}
        <div className="md:col-span-5 bg-slate-950/40 p-4 rounded-2xl border border-white/10 flex flex-col items-center justify-center relative">
          <span className="absolute top-3 left-3 text-[10px] text-slate-500 uppercase tracking-widest font-semibold">Interactive Map</span>
          
          <svg className="w-full max-w-[240px] h-[340px]" viewBox="0 0 400 500">
            {/* Connection lines */}
            {/* Seoul to Daejeon */}
            <line 
              x1="160" y1="110" x2="220" y2="280" 
              stroke={selectedDeparture === 'seoul' ? '#2dd4bf' : '#1e293b'} 
              strokeWidth={selectedDeparture === 'seoul' ? '3' : '1.5'} 
              className={selectedDeparture === 'seoul' ? 'map-line-dash' : ''}
              style={{ transition: 'stroke 0.3s, stroke-width 0.3s' }}
            />
            
            {/* Incheon to Daejeon */}
            <line 
              x1="100" y1="130" x2="220" y2="280" 
              stroke={selectedDeparture === 'incheon' ? '#2dd4bf' : '#1e293b'} 
              strokeWidth={selectedDeparture === 'incheon' ? '3' : '1.5'} 
              className={selectedDeparture === 'incheon' ? 'map-line-dash' : ''}
              style={{ transition: 'stroke 0.3s, stroke-width 0.3s' }}
            />

            {/* Ansan to Daejeon */}
            <line 
              x1="110" y1="170" x2="220" y2="280" 
              stroke={selectedDeparture === 'ansan' ? '#2dd4bf' : '#1e293b'} 
              strokeWidth={selectedDeparture === 'ansan' ? '3' : '1.5'} 
              className={selectedDeparture === 'ansan' ? 'map-line-dash' : ''}
              style={{ transition: 'stroke 0.3s, stroke-width 0.3s' }}
            />

            {/* Suwon to Daejeon */}
            <line 
              x1="170" y1="180" x2="220" y2="280" 
              stroke={selectedDeparture === 'suwon' ? '#2dd4bf' : '#1e293b'} 
              strokeWidth={selectedDeparture === 'suwon' ? '3' : '1.5'} 
              className={selectedDeparture === 'suwon' ? 'map-line-dash' : ''}
              style={{ transition: 'stroke 0.3s, stroke-width 0.3s' }}
            />

            {/* Gwangju to Daejeon */}
            <line 
              x1="140" y1="410" x2="220" y2="280" 
              stroke={selectedDeparture === 'gwangju' ? '#2dd4bf' : '#1e293b'} 
              strokeWidth={selectedDeparture === 'gwangju' ? '3' : '1.5'} 
              className={selectedDeparture === 'gwangju' ? 'map-line-dash' : ''}
              style={{ transition: 'stroke 0.3s, stroke-width 0.3s' }}
            />

            {/* Busan to Daejeon */}
            <line 
              x1="330" y1="420" x2="220" y2="280" 
              stroke={selectedDeparture === 'busan' ? '#2dd4bf' : '#1e293b'} 
              strokeWidth={selectedDeparture === 'busan' ? '3' : '1.5'} 
              className={selectedDeparture === 'busan' ? 'map-line-dash' : ''}
              style={{ transition: 'stroke 0.3s, stroke-width 0.3s' }}
            />

            {/* Target Hub: Daejeon */}
            <g id="node-daejeon" className="cursor-default">
              <circle cx="220" cy="280" r="16" fill="#0f172a" stroke="#2dd4bf" strokeWidth="4" />
              <circle cx="220" cy="280" r="6" fill="#2dd4bf" className="animate-ping opacity-75" />
              <circle cx="220" cy="280" r="5" fill="#2dd4bf" />
              <text x="220" y="318" fill="#2dd4bf" fontSize="12" fontWeight="bold" textAnchor="middle">대전 (도착지)</text>
            </g>

            {/* Nodes for Departure Cities */}
            {/* Seoul */}
            <g 
              id="node-seoul" 
              onClick={() => onSelectDeparture('seoul')} 
              className="cursor-pointer group select-none"
            >
              <circle 
                cx="160" cy="110" r={selectedDeparture === 'seoul' ? "12" : "9"} 
                fill="#1e293b" 
                stroke={selectedDeparture === 'seoul' ? "#2dd4bf" : "#6366f1"} 
                strokeWidth={selectedDeparture === 'seoul' ? "3" : "2"} 
                style={{ transition: 'all 0.2s' }}
              />
              <circle cx="160" cy="110" r="4" fill={selectedDeparture === 'seoul' ? "#2dd4bf" : "#6366f1"} />
              <text x="160" y="91" fill={selectedDeparture === 'seoul' ? "#2dd4bf" : "#cbd5e1"} fontSize="11" fontWeight="600" textAnchor="middle">서울</text>
            </g>

            {/* Incheon */}
            <g 
              id="node-incheon" 
              onClick={() => onSelectDeparture('incheon')} 
              className="cursor-pointer group select-none"
            >
              <circle 
                cx="100" cy="130" r={selectedDeparture === 'incheon' ? "12" : "9"} 
                fill="#1e293b" 
                stroke={selectedDeparture === 'incheon' ? "#2dd4bf" : "#6366f1"} 
                strokeWidth={selectedDeparture === 'incheon' ? "3" : "2"} 
                style={{ transition: 'all 0.2s' }}
              />
              <circle cx="100" cy="130" r="4" fill={selectedDeparture === 'incheon' ? "#2dd4bf" : "#6366f1"} />
              <text x="70" y="134" fill={selectedDeparture === 'incheon' ? "#2dd4bf" : "#cbd5e1"} fontSize="11" fontWeight="600" textAnchor="middle">인천</text>
            </g>

            {/* Ansan */}
            <g 
              id="node-ansan" 
              onClick={() => onSelectDeparture('ansan')} 
              className="cursor-pointer group select-none"
            >
              <circle 
                cx="110" cy="170" r={selectedDeparture === 'ansan' ? "13" : "10"} 
                fill="#1e293b" 
                stroke={selectedDeparture === 'ansan' ? "#2dd4bf" : "#38bdf8"} 
                strokeWidth="3" 
                style={{ transition: 'all 0.2s' }}
              />
              <circle cx="110" cy="170" r="4" fill={selectedDeparture === 'ansan' ? "#2dd4bf" : "#38bdf8"} />
              <text x="72" y="174" fill={selectedDeparture === 'ansan' ? "#2dd4bf" : "#38bdf8"} fontSize="12" fontWeight="bold" textAnchor="middle">안산 📍</text>
            </g>

            {/* Suwon */}
            <g 
              id="node-suwon" 
              onClick={() => onSelectDeparture('suwon')} 
              className="cursor-pointer group select-none"
            >
              <circle 
                cx="170" cy="180" r={selectedDeparture === 'suwon' ? "12" : "9"} 
                fill="#1e293b" 
                stroke={selectedDeparture === 'suwon' ? "#2dd4bf" : "#6366f1"} 
                strokeWidth={selectedDeparture === 'suwon' ? "3" : "2"} 
                style={{ transition: 'all 0.2s' }}
              />
              <circle cx="170" cy="180" r="4" fill={selectedDeparture === 'suwon' ? "#2dd4bf" : "#6366f1"} />
              <text x="205" y="184" fill={selectedDeparture === 'suwon' ? "#2dd4bf" : "#cbd5e1"} fontSize="11" fontWeight="600" textAnchor="middle">수원</text>
            </g>

            {/* Gwangju */}
            <g 
              id="node-gwangju" 
              onClick={() => onSelectDeparture('gwangju')} 
              className="cursor-pointer group select-none"
            >
              <circle 
                cx="140" cy="410" r={selectedDeparture === 'gwangju' ? "12" : "9"} 
                fill="#1e293b" 
                stroke={selectedDeparture === 'gwangju' ? "#2dd4bf" : "#6366f1"} 
                strokeWidth={selectedDeparture === 'gwangju' ? "3" : "2"} 
                style={{ transition: 'all 0.2s' }}
              />
              <circle cx="140" cy="410" r="4" fill={selectedDeparture === 'gwangju' ? "#2dd4bf" : "#6366f1"} />
              <text x="140" y="435" fill={selectedDeparture === 'gwangju' ? "#2dd4bf" : "#cbd5e1"} fontSize="11" fontWeight="600" textAnchor="middle">광주</text>
            </g>

            {/* Busan */}
            <g 
              id="node-busan" 
              onClick={() => onSelectDeparture('busan')} 
              className="cursor-pointer group select-none"
            >
              <circle 
                cx="330" cy="420" r={selectedDeparture === 'busan' ? "12" : "9"} 
                fill="#1e293b" 
                stroke={selectedDeparture === 'busan' ? "#2dd4bf" : "#6366f1"} 
                strokeWidth={selectedDeparture === 'busan' ? "3" : "2"} 
                style={{ transition: 'all 0.2s' }}
              />
              <circle cx="330" cy="420" r="4" fill={selectedDeparture === 'busan' ? "#2dd4bf" : "#6366f1"} />
              <text x="330" y="445" fill={selectedDeparture === 'busan' ? "#2dd4bf" : "#cbd5e1"} fontSize="11" fontWeight="600" textAnchor="middle">부산</text>
            </g>
          </svg>
        </div>

        {/* Real-time Route Efficiency Details (7 Cols) */}
        <div className="md:col-span-7 space-y-4">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">선택된 출발지 :</span>
            <span id="activeDepName" className="text-sm font-extrabold text-teal-400 px-2.5 py-1 bg-teal-500/20 border border-teal-500/30 rounded-lg">
              {depData.name}
            </span>
          </div>

          {/* Main Recommendation Panel */}
          <div className="bg-slate-950/40 border border-white/10 p-4 rounded-2xl">
            <p className="text-xs font-semibold text-indigo-400 flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>최적의 이동조합 추천</span>
            </p>
            <p id="routeRecommend" className="text-sm font-bold text-slate-100 mt-1 leading-relaxed">
              {depData.bestRecommend}
            </p>
          </div>

          {/* Transit Breakdown Graph Bars */}
          <div className="space-y-3" id="transitGraphContainer">
            {depData.transports.map((t, idx) => {
              const barColor = t.isBest ? 'bg-indigo-500' : 'bg-slate-700';

              return (
                <div key={idx} className="space-y-1">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-bold text-slate-200 flex items-center gap-1.5">
                      {t.name}
                      {t.isBest && (
                        <span className="text-[9px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.2 rounded border border-indigo-500/20 font-extrabold">
                          최단시간
                        </span>
                      )}
                    </span>
                    <span className="font-medium text-slate-400 text-[11px]">{t.time} ({t.efficiency})</span>
                  </div>
                  <div className="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-850">
                    <div 
                      className={`${barColor} h-full rounded-full transition-all duration-1000`} 
                      style={{ width: `${t.pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </div>
  );
}
