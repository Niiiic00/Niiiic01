/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Train, Car, Check, Plus, Lightbulb } from 'lucide-react';
import { Restaurant } from '../types';

interface RestaurantCardProps {
  restaurant: Restaurant;
  isAdded: boolean;
  onToggle: () => void;
  key?: number;
}

export default function RestaurantCard({ restaurant, isAdded, onToggle }: RestaurantCardProps) {
  const tagBadges = restaurant.tags.map(t => `#${t}`).join(' ');

  let catBadgeText = "";
  let catBadgeStyle = "";
  switch (restaurant.category) {
    case "korean": 
      catBadgeText = "한식"; 
      catBadgeStyle = "bg-sky-500/10 text-sky-400 border-sky-500/20"; 
      break;
    case "chinese": 
      catBadgeText = "중식"; 
      catBadgeStyle = "bg-rose-500/10 text-rose-400 border-rose-500/20"; 
      break;
    case "japanese": 
      catBadgeText = "일식"; 
      catBadgeStyle = "bg-indigo-500/10 text-indigo-400 border-indigo-500/20"; 
      break;
    case "western": 
      catBadgeText = "양식"; 
      catBadgeStyle = "bg-purple-500/10 text-purple-400 border-purple-500/20"; 
      break;
    case "dessert": 
      catBadgeText = "디저트"; 
      catBadgeStyle = "bg-pink-500/10 text-pink-400 border-pink-500/20"; 
      break;
    default:
      catBadgeText = "기타";
      catBadgeStyle = "bg-slate-500/10 text-slate-400 border-slate-500/20";
  }

  return (
    <div id={`restaurant-card-${restaurant.id}`} className="bg-white/5 backdrop-blur-sm rounded-3xl p-5 border border-white/10 hover:bg-white/10 hover:border-white/25 hover:shadow-2xl transition-all flex flex-col justify-between group">
      <div>
        {/* Header elements */}
        <div className="flex justify-between items-start gap-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl bg-slate-950/40 border border-white/5 p-2.5 rounded-xl block group-hover:scale-110 transition-transform">
              {restaurant.icon}
            </span>
            <span className={`text-[11px] font-bold px-2 py-0.5 rounded border ${catBadgeStyle}`}>
              {catBadgeText}
            </span>
          </div>
          <span className={`text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
            restaurant.nearSubway 
              ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' 
              : 'bg-amber-500/10 text-amber-400 border border-amber-500/20'
          }`}>
            {restaurant.nearSubway ? (
              <Train className="w-3.5 h-3.5 text-emerald-400" />
            ) : (
              <Car className="w-3.5 h-3.5 text-amber-400" />
            )}
            <span>{restaurant.subway}</span>
          </span>
        </div>

        {/* Middle details description */}
        <div className="mt-4">
          <h4 className="font-bold text-slate-100 text-base flex items-center gap-1.5">
            {restaurant.name}
          </h4>
          <p className="text-[11px] text-teal-400 font-bold mt-1">
            시그니처: {restaurant.menu}
          </p>
          <p className="text-xs text-slate-300 mt-2.5 leading-relaxed min-h-[3rem]">
            {restaurant.description}
          </p>
          <div className="text-[11px] text-slate-300 mt-3 bg-slate-950/40 p-2.5 rounded-xl border border-white/5 flex items-start gap-1.5">
            <Lightbulb className="w-3.5 h-3.5 text-indigo-400 shrink-0 mt-0.5" />
            <p>
              <strong className="text-indigo-400">꿀팁:</strong> {restaurant.tips}
            </p>
          </div>
        </div>
      </div>

      {/* Footer and Action button */}
      <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between gap-2">
        <span className="text-[10px] text-slate-500 font-medium truncate max-w-[150px]" title={tagBadges}>
          {tagBadges}
        </span>
        <button 
          onClick={onToggle} 
          className={`text-xs font-bold py-2.5 px-4 rounded-xl transition duration-150 flex items-center space-x-1.5 shrink-0 cursor-pointer ${
            isAdded 
              ? 'bg-white/10 text-indigo-300 border border-white/10 hover:bg-white/20' 
              : 'bg-indigo-500 hover:bg-indigo-600 text-white active:scale-95 shadow-lg shadow-indigo-500/10'
          }`}
        >
          {isAdded ? (
            <>
              <Check className="w-3.5 h-3.5" />
              <span>추가됨</span>
            </>
          ) : (
            <>
              <Plus className="w-3.5 h-3.5" />
              <span>일정 추가</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
}
