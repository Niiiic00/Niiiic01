/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Search, Train } from 'lucide-react';
import { CategoryCode } from '../types';

interface FiltersProps {
  searchQuery: string;
  onSearchQueryChange: (val: string) => void;
  activeCategory: CategoryCode;
  onSelectCategory: (cat: CategoryCode) => void;
  filterNearSubway: boolean;
  onToggleSubwayOnly: () => void;
}

export default function Filters({
  searchQuery,
  onSearchQueryChange,
  activeCategory,
  onSelectCategory,
  filterNearSubway,
  onToggleSubwayOnly,
}: FiltersProps) {
  const categories: { code: CategoryCode; label: string; emoji: string }[] = [
    { code: 'all', label: '전체보기', emoji: '✨' },
    { code: 'korean', label: '🍚 한식', emoji: '🍚' },
    { code: 'chinese', label: '🍜 중식', emoji: '🍜' },
    { code: 'japanese', label: '🍣 일식', emoji: '🍣' },
    { code: 'western', label: '🍝 양식', emoji: '🍝' },
    { code: 'dessert', label: '🧁 디저트 (빵·케이크·떡)', emoji: '🧁' },
  ];

  return (
    <div className="bg-white/5 backdrop-blur-md p-6 rounded-3xl border border-white/10 space-y-5 shadow-lg relative overflow-hidden">
      {/* Small light glow */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-teal-400/5 rounded-full blur-2xl pointer-events-none"></div>

      {/* Search Input */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-slate-400 w-5 h-5" />
        <input 
          type="text" 
          value={searchQuery}
          onChange={(e) => onSearchQueryChange(e.target.value)}
          placeholder="맛집 이름, 시그니처 메뉴, 태그 키워드 검색 (예: 스마일, 뇨끼, 마들렌...)" 
          className="w-full pl-11 pr-4 py-3 rounded-2xl border border-white/10 bg-slate-950/40 text-slate-200 focus:bg-slate-950/60 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition outline-none text-sm placeholder-slate-500"
        />
      </div>

      {/* Food Category Filters */}
      <div className="space-y-2">
        <span className="text-xs font-bold text-slate-400 tracking-wider uppercase block">푸드 카테고리 세분화</span>
        <div className="flex flex-wrap gap-1.5">
          {categories.map((cat) => {
            const isActive = activeCategory === cat.code;
            return (
              <button
                key={cat.code}
                onClick={() => onSelectCategory(cat.code)}
                className={`text-xs font-bold px-4 py-2.5 rounded-xl transition cursor-pointer ${
                  isActive 
                    ? 'bg-indigo-500 text-white font-extrabold shadow-lg shadow-indigo-500/20 border border-indigo-400/30' 
                    : 'bg-white/10 text-slate-300 hover:bg-white/20 border border-white/5'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* Subway / Walk filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pt-3 border-t border-white/10 gap-3">
        <span className="text-xs text-slate-400 flex items-center gap-1.5">
          <span className="text-sky-400">❄️</span>
          <span>무더위 최적화 뚜벅이 안심 필터</span>
        </span>
        <button 
          onClick={onToggleSubwayOnly}
          className={`flex items-center space-x-1.5 text-xs font-bold px-4 py-2.5 rounded-xl transition cursor-pointer ${
            filterNearSubway 
              ? 'bg-indigo-500 hover:bg-indigo-600 border border-indigo-400/40 text-white shadow-md shadow-indigo-500/20' 
              : 'border border-white/10 bg-white/5 hover:bg-white/10 text-slate-300'
          }`}
        >
          <Train className="w-4 h-4 text-teal-400" />
          <span>지하철역 매우 가까움 (도보 10분내)</span>
        </button>
      </div>
    </div>
  );
}
