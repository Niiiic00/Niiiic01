/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { DepartureCode, DepartureData, Restaurant } from './types';

export const departuresData: Record<DepartureCode, DepartureData> = {
  ansan: {
    name: "안산시 📍",
    bestRecommend: "수원역까지 수인분당선 이동 후 KTX를 환승하거나, 터미널 고속버스를 타는 것보다 KTX 환승이 압도적으로 빠르고 쾌적합니다!",
    transports: [
      { name: "수원역 환승 + KTX (추천)", time: "1시간 20분", efficiency: "최상 (피로도 없음)", pct: 100, isBest: true },
      { name: "광명역 자차/택시 + KTX", time: "1시간 30분", efficiency: "우수 (연결 차편 확인 필요)", pct: 85, isBest: false },
      { name: "안산버스터미널 고속버스", time: "1시간 55분", efficiency: "보통 (교통체증 우려)", pct: 60, isBest: false }
    ]
  },
  seoul: {
    name: "서울특별시",
    bestRecommend: "서울역에서 KTX를 타고 대전역까지 1시간 만에 돌파하는 것이 정석입니다. 강남권 출발의 경우 수서역 SRT가 훨씬 쾌적합니다.",
    transports: [
      { name: "서울역 KTX 직행", time: "1시간 00분", efficiency: "최상 (배차간격 10분)", pct: 100, isBest: true },
      { name: "수서역 SRT 직행", time: "1시간 03분", efficiency: "최상 (강남권 최적)", pct: 98, isBest: false },
      { name: "서울고속버스터미널 버스", time: "2시간 00분", efficiency: "보통 (주말 체증)", pct: 50, isBest: false }
    ]
  },
  incheon: {
    name: "인천광역시",
    bestRecommend: "검암/인천역에서 송도역 KTX(개통 예정 포함)를 이용하거나, 광명역으로 가는 셔틀버스를 탄 후 KTX를 타는 노선이 정체 부담이 적습니다.",
    transports: [
      { name: "광명역 이동 KTX 연계", time: "1시간 40분", efficiency: "우수", pct: 90, isBest: true },
      { name: "인천 종합터미널 시외버스", time: "2시간 10분", efficiency: "보통", pct: 65, isBest: false },
      { name: "자차 이동 (서해안 고속도로)", time: "2시간 00분", efficiency: "피로도 있음", pct: 55, isBest: false }
    ]
  },
  suwon: {
    name: "수원시",
    bestRecommend: "수원역에서 출발하는 KTX 직행 혹은 가성비가 훌륭한 ITX-새마을을 타는 것이 가장 빠르고 확실한 뚜벅이 코스입니다.",
    transports: [
      { name: "수원역 KTX 직행", time: "1시간 10분", efficiency: "최상", pct: 100, isBest: true },
      { name: "ITX-새마을 / 무궁화호", time: "1시간 30분", efficiency: "가성비 극대화", pct: 85, isBest: false },
      { name: "수원 버스터미널 직행", time: "1시간 45분", efficiency: "보통", pct: 60, isBest: false }
    ]
  },
  gwangju: {
    name: "광주광역시",
    bestRecommend: "광주송정역에서 오송역 경유 KTX를 타거나 호남선 직행 KTX를 타고 대전조차장/서대전역으로 직행하시는 것을 최우선으로 권장합니다.",
    transports: [
      { name: "광주송정역 KTX 직행", time: "1시간 25분", efficiency: "우수", pct: 95, isBest: true },
      { name: "유스퀘어 고속버스 직행", time: "2시간 15분", efficiency: "보통", pct: 65, isBest: false }
    ]
  },
  busan: {
    name: "부산광역시",
    bestRecommend: "부산역에서 경부선 KTX를 타면 중간 정차역이 적어 대전역까지 1시간 40분 이내에 주파하는 초쾌속 이동이 가능합니다.",
    transports: [
      { name: "부산역 KTX 직행", time: "1시간 38분", efficiency: "최상 (쾌적)", pct: 100, isBest: true },
      { name: "부산서부버스터미널 고속버스", time: "3시간 00분", efficiency: "피로도 높음", pct: 40, isBest: false }
    ]
  }
};

export const restaurants: Restaurant[] = [
  {
    id: 1,
    name: "미소본가 스마일칼국수",
    category: "korean",
    subway: "중앙로역 (도보 8분)",
    nearSubway: true,
    menu: "손칼국수, 부추가득 김밥, 수육",
    description: "백종원의 3대천왕 손칼국수 명가. 부드럽고 쫄깃한 자가제면 손면발에 들깨가루와 참기름 가득 김밥을 국물에 적셔 드시는 극락의 맛.",
    tips: "일요일 정기 휴무이므로, 월요일 도착 직후 첫 점심식사로 강력추천!",
    icon: "🍚",
    tags: ["손칼국수", "김밥필수", "백종원3대천왕"]
  },
  {
    id: 2,
    name: "정동문화사",
    category: "dessert",
    subway: "대전역 (도보 10분)",
    nearSubway: true,
    menu: "휘낭시에, 까눌레, 에그타르트",
    description: "구움과자 애호가들이 전국에서 줄 서는 명품 디저트숍. 한 번 맛보면 잊지 못하는 극강의 바삭함과 촉촉한 속결이 일품입니다.",
    tips: "조기 품절률이 대전 내 탑티어급으로 높으니 오전에 최우선으로 빵택시 찍고 가세요!",
    icon: "🧁",
    tags: ["구움과자성지", "겉바속촉", "오픈런필수"]
  },
  {
    id: 3,
    name: "몽심 (도안점 / 한남대본점)",
    category: "dessert",
    subway: "자차/택시 추천",
    nearSubway: false,
    menu: "밀키 연유 마들렌, 에그타르트",
    description: "대전 로컬 빵 축제 어워즈에서 성심당을 뒤흔들며 마들렌 강자로 떠오른 디저트 전문점. 밀키 연유 마들렌은 선물 패키지용으로 최고.",
    tips: "빵택시나 택시를 타고 안전하고 쾌적하게 방문하시는 것을 추천드립니다.",
    icon: "🧁",
    tags: ["마들렌1위", "로컬인기폭발", "구움과자"]
  },
  {
    id: 4,
    name: "빵 한모금",
    category: "dessert",
    subway: "동구 자양동 (버스/택시 8분)",
    nearSubway: false,
    menu: "시그니처 미트파이, 결 살아있는 크로아상",
    description: "프랑스 정통 페이스트리 결을 유지하며 가벼우면서도 바삭한 완벽한 풍미를 내는 곳. 짭조름한 미트파이는 대중적인 취향을 저격합니다.",
    tips: "매콤한 맛도 선택 가능하므로, 든든하고 캐주얼한 브런치로 적극 활용해보세요.",
    icon: "🧁",
    tags: ["미트파이", "결페이스트리", "빵지순례"]
  },
  {
    id: 5,
    name: "태화장 (Taehwajang)",
    category: "chinese",
    subway: "대전역 (도보 7분)",
    nearSubway: true,
    menu: "수제 멘보샤, 난자완스, 삼선간짜장",
    description: "성시경의 '먹을텐데'에 소개된 50년 정통 중식 노포. 빵빵하고 육즙 가득한 멘보샤는 식빵 두께보다 다진 새우가 3배 두꺼워 호평 일색.",
    tips: "주말에는 항상 긴 줄이 늘어서므로 브레이크 타임 직후를 공략하는 것이 현명합니다.",
    icon: "🍜",
    tags: ["백년가게", "성시경맛집", "멘보샤우수"]
  },
  {
    id: 6,
    name: "토미야 (Tomiya)",
    category: "japanese",
    subway: "정부청사역 (도보 12분 / 택시권장)",
    nearSubway: false,
    menu: "냉 붓카케 우동, 바삭한 야채/닭 튀김",
    description: "일본 사누키 전통 수타 방식을 고수해 만든 압도적인 면 탄력을 가진 일식 수제 우동 전문점. 쫄깃쫄깃 입안을 치는 식감이 예술.",
    tips: "여름철 더위를 날리는 차가운 붓카케 우동에 바삭한 가라아게 튀김 토핑을 조합해 보세요.",
    icon: "🍣",
    tags: ["사누키자가제면", "냉우동명소", "대기필수"]
  },
  {
    id: 7,
    name: "카라멜 (KARAMEL)",
    category: "western",
    subway: "중앙로역 (도보 7분)",
    nearSubway: true,
    menu: "시그니처 버섯뇨끼, 알배추 샐러드, 라자냐",
    description: "감성 가득한 모던하고 힙한 인테리어 속에서 즐기는 이탈리안 다이닝. 부드러우면서도 쫀득하게 씹히는 버섯 뇨끼는 단연 압도적 만족감.",
    tips: "미리 모바일 대기 앱을 켜서 웨이팅을 체크하고 방문하시는 것이 편합니다.",
    icon: "🍝",
    tags: ["캐주얼양식", "버섯뇨끼대표", "힙한감성"]
  },
  {
    id: 8,
    name: "남씨네 떡집",
    category: "dessert",
    subway: "서대전네거리역 (도보 12분)",
    nearSubway: false,
    menu: "과일 생크림 찹쌀떡, 쑥 인절미",
    description: "빵의 대전에서 전통 떡에 신세대 과일&생크림 감성을 융합하여 떡지순례 유행을 일으킨 로컬 명소. 얇고 쫀득한 피가 달콤합니다.",
    tips: "냉장고에 잠시 넣어 차갑게 해서 아이스크림처럼 베어 먹는 방식이 베스트!",
    icon: "🧁",
    tags: ["퓨전떡집", "생크림찹쌀떡", "시원한디저트"]
  }
];
